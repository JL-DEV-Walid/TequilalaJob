# esx_tequilala
Hello Everyone, this is a script i made a while ago for a friend. I wanted to share with you my little project. 

I will not provide any support since i am not using it anymore!

[REQUIREMENTS]  

Dependencies For Full Working 

es_extended => https://github.com/ESX-Org/es_extended

esx_society => https://github.com/ESX-Org/esx_society 

instance => https://github.com/ESX-Org/instance 

esx_skin => https://github.com/ESX-Org/esx_skin 

esx_jobs => https://github.com/ESX-Org/esx_jobs 

esx_menu_list => https://github.com/ESX-Org/esx_menu_list 

esx_menu_dialog => https://github.com/ESX-Org/esx_menu_dialog 

esx_menu_default => https://github.com/ESX-Org/esx_menu_default

[INSTALLATION]

Copy the folder "esx_tequilalajob" into your resources folder

Add this on your server.cfg :

start esx_tequilalajob
Import the "esx_tequilalajob.sql" into your Database (Mysql only)

You can change every spawn point and marker on the config.lua file


[EXIGENCES]

Dépendances Pour un travail complet

es_extended => https://github.com/ESX-Org/es_extended

esx_society => https://github.com/ESX-Org/esx_society

instance => https://github.com/ESX-Org/instance

esx_skin => https://github.com/ESX-Org/esx_skin

esx_jobs => https://github.com/ESX-Org/esx_jobs

esx_menu_list => https://github.com/ESX-Org/esx_menu_list

esx_menu_dialog => https://github.com/ESX-Org/esx_menu_dialog

esx_menu_default => https://github.com/ESX-Org/esx_menu_default

[INSTALLATION]

Copiez le dossier "esx_tequilalajob" dans votre dossier de ressources

Ajoutez ceci sur votre server.cfg:

démarrer esx_tequilalajob
Importez le "esx_tequilalajob.sql" dans votre base de données (Mysql uniquement)

Vous pouvez changer chaque point de spawn et marqueur sur le fichier config.lua
